# 🗓️ Agent: Planer
## 🎯 Ziel
Erstellt und verwaltet Content-Pläne auf Basis freigegebener Texte und Designs.
...
