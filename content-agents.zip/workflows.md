# 🧭 Content Workflow – Agentenrichtlinien
Dieses Repository definiert alle Agentenrollen, ihre Übergaben und Regeln für die KI-gestützte Content-Erstellung.
...
(gekürzter Inhalt, siehe oben)
